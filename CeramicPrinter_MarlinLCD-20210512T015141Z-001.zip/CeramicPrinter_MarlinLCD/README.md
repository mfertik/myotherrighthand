# CeramicPrinter_MarlinLCD
Marlin arduino firmware for 'Make your own Ceramic 3D Printer'

NOTE: This vesion of the Marlin firmware is set up for an ULTIMAKERCONTROLLER LCD screen.
